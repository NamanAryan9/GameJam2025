import React, { useState, useEffect, useCallback } from 'react';
import { Sparkles, Trophy, ArrowRightCircle, Medal, Volume2, VolumeX, Zap, Shield, Clock, Ghost } from 'lucide-react';

// Fake initial leaderboard data
const initialLeaderboard = [
  { name: "DreamClicker", score: 150 },
  { name: "VibeQueen", score: 145 },
  { name: "ClickMaster", score: 140 },
  { name: "StarChaser", score: 135 },
  { name: "CosmicTap", score: 130 }
];

const achievements = {
  firstClick: { name: "First Click!", description: "Click your first button", score: 1 },
  speedDemon: { name: "Speed Demon", description: "Get 10 clicks in 3 seconds", score: 10 },
  multiplierMaster: { name: "Multiplier Master", description: "Use 3 multipliers", score: 20 },
  highScore: { name: "High Scorer", description: "Beat the top score", score: 150 },
  powerCollector: { name: "Power Collector", description: "Collect all types of powerups", score: 30 },
  comboMaster: { name: "Combo Master", description: "Get 20 clicks in 5 seconds", score: 40 },
  ultraSpeed: { name: "Ultra Speed", description: "Click 5 times in 1 second", score: 50 },
  trickster: { name: "Trickster", description: "Avoid 5 fake balls", score: 25 }
};

// AI taunts that will be shown when player misses
const aiTaunts = [
  "Oops! Too slow, {name}!",
  "My grandma clicks faster than that, {name}!",
  "Are you even trying, {name}?",
  "Did you fall asleep, {name}?",
  "Nice miss, {name}! (Not really)",
  "Having trouble keeping up, {name}?",
  "Maybe try using both hands, {name}!",
  "That button's not going to click itself, {name}!",
  "I've seen sloths with better reflexes, {name}!",
  "Is your mouse broken, {name}? Or just your aim?"
];

// Sound URLs - using small, lightweight sound files
const sounds = {
  click: "https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3",
  achievement: "https://assets.mixkit.co/active_storage/sfx/2569/2569-preview.mp3",
  multiplier: "https://assets.mixkit.co/active_storage/sfx/2570/2570-preview.mp3",
  powerup: "https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3",
  fake: "https://assets.mixkit.co/active_storage/sfx/2572/2572-preview.mp3"
};

type PowerUp = {
  type: 'multiplier' | 'timeBonus' | 'megaPoints';
  position: { x: number; y: number };
  icon: React.ReactNode;
};

type FakeBall = {
  position: { x: number; y: number };
  size: number;
};

function App() {
  const [playerName, setPlayerName] = useState("");
  const [gameStarted, setGameStarted] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [multiplier, setMultiplier] = useState(1);
  const [buttonPosition, setButtonPosition] = useState({ x: 50, y: 50 });
  const [buttonSize, setButtonSize] = useState(100);
  const [leaderboard, setLeaderboard] = useState(initialLeaderboard);
  const [gameOver, setGameOver] = useState(false);
  const [hue, setHue] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [unlockedAchievements, setUnlockedAchievements] = useState(new Set());
  const [recentClicks, setRecentClicks] = useState<number[]>([]);
  const [multiplierCount, setMultiplierCount] = useState(0);
  const [showAchievement, setShowAchievement] = useState<string | null>(null);
  const [powerUps, setPowerUps] = useState<PowerUp[]>([]);
  const [collectedPowerUps, setCollectedPowerUps] = useState(new Set());
  const [fakeBalls, setFakeBalls] = useState<FakeBall[]>([]);
  const [avoidedFakeBalls, setAvoidedFakeBalls] = useState(0);
  const [currentTaunt, setCurrentTaunt] = useState<string | null>(null);

  // Handle portal parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('portal') === 'true') {
      const name = params.get('username') || 'Player';
      setPlayerName(name);
      setGameStarted(true);
    }
  }, []);

  // Sound effect player
  const playSound = useCallback((soundType: keyof typeof sounds) => {
    if (!soundEnabled) return;
    const audio = new Audio(sounds[soundType]);
    audio.volume = 0.3;
    audio.play().catch(() => {}); // Ignore autoplay restrictions
  }, [soundEnabled]);

  // AI Taunt System
  const showRandomTaunt = useCallback(() => {
    if (Math.random() < 0.3) { // 30% chance to show taunt
      const taunt = aiTaunts[Math.floor(Math.random() * aiTaunts.length)];
      const personalizedTaunt = taunt.replace('{name}', playerName);
      setCurrentTaunt(personalizedTaunt);
      setTimeout(() => setCurrentTaunt(null), 2000);
    }
  }, [playerName]);

  // Fake Ball System
  useEffect(() => {
    if (!gameStarted) return;

    const spawnFakeBall = () => {
      const newFakeBall: FakeBall = {
        position: {
          x: Math.random() * 80 + 10,
          y: Math.random() * 80 + 10
        },
        size: buttonSize
      };

      setFakeBalls(prev => [...prev, newFakeBall]);
      setTimeout(() => {
        setFakeBalls(prev => prev.filter(ball => ball !== newFakeBall));
        setAvoidedFakeBalls(prev => prev + 1);
        if (avoidedFakeBalls >= 4) {
          const newAchievements = new Set(unlockedAchievements);
          if (!newAchievements.has('trickster')) {
            newAchievements.add('trickster');
            setUnlockedAchievements(newAchievements);
            playSound('achievement');
          }
        }
      }, 2000);
    };

    const interval = setInterval(spawnFakeBall, 4000);
    return () => clearInterval(interval);
  }, [gameStarted, buttonSize, avoidedFakeBalls, unlockedAchievements, playSound]);

  // Achievement handler
  const checkAchievements = useCallback(() => {
    const newAchievements = new Set(unlockedAchievements);
    let achieved = false;

    if (score >= 1 && !newAchievements.has('firstClick')) {
      newAchievements.add('firstClick');
      achieved = true;
    }

    if (recentClicks.length >= 10 && !newAchievements.has('speedDemon')) {
      newAchievements.add('speedDemon');
      achieved = true;
    }

    if (multiplierCount >= 3 && !newAchievements.has('multiplierMaster')) {
      newAchievements.add('multiplierMaster');
      achieved = true;
    }

    if (score > Math.max(...leaderboard.map(l => l.score)) && !newAchievements.has('highScore')) {
      newAchievements.add('highScore');
      achieved = true;
    }

    if (collectedPowerUps.size >= 3 && !newAchievements.has('powerCollector')) {
      newAchievements.add('powerCollector');
      achieved = true;
    }

    const last5Seconds = recentClicks.filter(time => Date.now() - time < 5000);
    if (last5Seconds.length >= 20 && !newAchievements.has('comboMaster')) {
      newAchievements.add('comboMaster');
      achieved = true;
    }

    const last1Second = recentClicks.filter(time => Date.now() - time < 1000);
    if (last1Second.length >= 5 && !newAchievements.has('ultraSpeed')) {
      newAchievements.add('ultraSpeed');
      achieved = true;
    }

    if (achieved) {
      playSound('achievement');
      const lastAchieved = Array.from(newAchievements).pop();
      setShowAchievement(lastAchieved || null);
      setTimeout(() => setShowAchievement(null), 3000);
    }

    setUnlockedAchievements(newAchievements);
  }, [score, recentClicks, multiplierCount, leaderboard, unlockedAchievements, playSound, collectedPowerUps]);

  // Dreamy background effect
  useEffect(() => {
    const interval = setInterval(() => {
      setHue((h) => (h + 1) % 360);
    }, 100);
    return () => clearInterval(interval);
  }, []);

  // Recent clicks tracker
  useEffect(() => {
    const now = Date.now();
    setRecentClicks(prev => [...prev, now].filter(time => now - time < 3000));
  }, [score]);

  // Power-up spawner
  useEffect(() => {
    if (!gameStarted) return;
    
    const spawnPowerUp = () => {
      const types: PowerUp['type'][] = ['multiplier', 'timeBonus', 'megaPoints'];
      const type = types[Math.floor(Math.random() * types.length)];
      const icons = {
        multiplier: <Zap className="w-6 h-6" />,
        timeBonus: <Clock className="w-6 h-6" />,
        megaPoints: <Shield className="w-6 h-6" />
      };

      const newPowerUp: PowerUp = {
        type,
        position: {
          x: Math.random() * 80 + 10,
          y: Math.random() * 80 + 10
        },
        icon: icons[type]
      };

      setPowerUps(prev => [...prev, newPowerUp]);
      setTimeout(() => {
        setPowerUps(prev => prev.filter(p => p !== newPowerUp));
      }, 3000);
    };

    const interval = setInterval(spawnPowerUp, 5000);
    return () => clearInterval(interval);
  }, [gameStarted]);

  // Game timer
  useEffect(() => {
    if (gameStarted && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft((time) => time - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0 && gameStarted) {
      endGame();
    }
  }, [gameStarted, timeLeft]);

  const endGame = useCallback(() => {
    setGameOver(true);
    setGameStarted(false);
    setLeaderboard((prev) => {
      const newLeaderboard = [...prev, { name: playerName, score }]
        .sort((a, b) => b.score - a.score)
        .slice(0, 5);
      return newLeaderboard;
    });
  }, [playerName, score]);

  const moveButton = () => {
    const x = Math.random() * 80 + 10;
    const y = Math.random() * 80 + 10;
    setButtonPosition({ x, y });
    showRandomTaunt();
  };

  const handleFakeBallClick = () => {
    playSound('fake');
    setScore(prev => Math.max(0, prev - 10));
    showRandomTaunt();
  };

  const handleButtonClick = (e: React.MouseEvent) => {
    if (!gameStarted || timeLeft === 0) return;
    
    // Prevent holding enter and moving mouse
    if (e.buttons !== 1) return;
    
    playSound('click');
    setScore((s) => s + (1 * multiplier));
    
    // Move button to random position
    moveButton();
    
    // Shrink button slightly
    setButtonSize((size) => Math.max(50, size - 0.5));
    
    // Random multiplier
    if (Math.random() < 0.05) {
      playSound('multiplier');
      setMultiplier(2);
      setMultiplierCount(count => count + 1);
      setTimeout(() => setMultiplier(1), 2000);
    }

    checkAchievements();
  };

  const collectPowerUp = (powerUp: PowerUp) => {
    playSound('powerup');
    setCollectedPowerUps(prev => new Set([...prev, powerUp.type]));

    switch (powerUp.type) {
      case 'multiplier':
        setMultiplier(prev => prev + 2);
        setTimeout(() => setMultiplier(1), 3000);
        break;
      case 'timeBonus':
        setTimeLeft(prev => prev + 5);
        break;
      case 'megaPoints':
        setScore(prev => prev + 50);
        break;
    }

    setPowerUps(prev => prev.filter(p => p !== powerUp));
  };

  const startGame = () => {
    if (!playerName) return;
    setGameStarted(true);
    setScore(0);
    setTimeLeft(30);
    setButtonSize(100);
    setButtonPosition({ x: 50, y: 50 });
    setGameOver(false);
    setRecentClicks([]);
    setMultiplierCount(0);
    setCollectedPowerUps(new Set());
    setPowerUps([]);
    setFakeBalls([]);
    setAvoidedFakeBalls(0);
    setCurrentTaunt(null);
  };

  const enterPortal = () => {
    const params = new URLSearchParams({
      username: playerName,
      color: 'blue',
      speed: '1',
      ref: window.location.href
    });
    window.location.href = `http://portal.pieter.com/?${params.toString()}`;
  };

  return (
    <div 
      className="min-h-screen w-full relative overflow-hidden"
      style={{
        background: `linear-gradient(${hue}deg, #ff6b6b, #4ecdc4)`
      }}
    >
      {/* Sound Toggle */}
      <button
        onClick={() => setSoundEnabled(!soundEnabled)}
        className="absolute top-4 left-4 bg-white/20 backdrop-blur-sm p-2 rounded-full"
      >
        {soundEnabled ? <Volume2 /> : <VolumeX />}
      </button>

      {/* Achievement Popup */}
      {showAchievement && (
        <div className="fixed top-8 left-1/2 -translate-x-1/2 bg-yellow-400 text-black px-6 py-3 rounded-full shadow-lg flex items-center gap-2 animate-bounce">
          <Medal className="w-5 h-5" />
          <span>Achievement Unlocked: {achievements[showAchievement as keyof typeof achievements].name}!</span>
        </div>
      )}

      {/* AI Taunt */}
      {currentTaunt && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 bg-red-500 text-white px-6 py-3 rounded-full shadow-lg animate-bounce">
          {currentTaunt}
        </div>
      )}

      {/* Vibe Jam Badge */}
      <a 
        target="_blank" 
        href="https://jam.pieter.com" 
        className="font-['system-ui'] fixed bottom-[-1px] right-[-1px] px-[7px] py-[7px] text-[14px] font-bold bg-white text-black no-underline z-[10000] rounded-tl-[12px] border border-white"
      >
        🕹️ Vibe Jam 2025
      </a>

      {/* Portal */}
      <div 
        onClick={enterPortal}
        className="absolute top-4 right-4 flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full cursor-pointer hover:bg-white/30 transition-all"
      >
        <ArrowRightCircle size={20} />
        <span>Enter Vibeverse Portal</span>
      </div>

      {!gameStarted && !gameOver ? (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white/20 backdrop-blur-sm p-8 rounded-xl">
          <h1 className="text-4xl font-bold mb-6 text-white text-center">Button Frenzy</h1>
          <input
            type="text"
            placeholder="Enter your name"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="w-full px-4 py-2 rounded-lg mb-4"
          />
          <button
            onClick={startGame}
            className="w-full bg-white text-black font-bold py-2 rounded-lg hover:bg-opacity-90 transition-all"
          >
            Start Game
          </button>
        </div>
      ) : (
        <div className="relative h-screen">
          {/* Game UI */}
          <div className="absolute top-16 left-4 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-lg">
            <p className="text-white">Time: {timeLeft}s</p>
            <p className="text-white">Score: {score}</p>
            {multiplier > 1 && (
              <p className="text-yellow-300">
                <Sparkles className="inline mr-1" />
                {multiplier}x Multiplier!
              </p>
            )}
          </div>

          {/* Fake Balls */}
          {fakeBalls.map((ball, index) => (
            <button
              key={`fake-${index}`}
              onClick={handleFakeBallClick}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 bg-white/50 rounded-full shadow-lg transition-all hover:bg-white/60 flex items-center justify-center"
              style={{
                left: `${ball.position.x}%`,
                top: `${ball.position.y}%`,
                width: `${ball.size}px`,
                height: `${ball.size}px`
              }}
            >
              <Ghost className="w-8 h-8 text-gray-500" />
            </button>
          ))}

          {/* Power-ups */}
          {powerUps.map((powerUp, index) => (
            <button
              key={index}
              onClick={() => collectPowerUp(powerUp)}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 bg-white/80 p-3 rounded-full hover:bg-white transition-all"
              style={{
                left: `${powerUp.position.x}%`,
                top: `${powerUp.position.y}%`
              }}
            >
              {powerUp.icon}
            </button>
          ))}

          {/* Main Button */}
          <button
            onMouseDown={handleButtonClick}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-full shadow-lg hover:shadow-xl transition-all active:scale-95 cursor-pointer z-10"
            style={{
              left: `${buttonPosition.x}%`,
              top: `${buttonPosition.y}%`,
              width: `${buttonSize}px`,
              height: `${buttonSize}px`,
              pointerEvents: 'all'
            }}
          >
            <Sparkles className="w-8 h-8" />
          </button>

          {/* Achievements */}
          <div className="absolute bottom-4 left-4 bg-white/20 backdrop-blur-sm p-4 rounded-lg max-w-xs">
            <h2 className="text-white font-bold mb-2 flex items-center gap-2">
              <Medal size={20} />
              Achievements
            </h2>
            {Object.entries(achievements).map(([key, achievement]) => (
              <div
                key={key}
                className={`text-sm mb-1 ${unlockedAchievements.has(key) ? 'text-yellow-300' : 'text-white/50'}`}
              >
                {achievement.name}
              </div>
            ))}
          </div>

          {/* Leaderboard */}
          <div className="absolute top-4 right-52 bg-white/20 backdrop-blur-sm p-4 rounded-lg pointer-events-none">
            <h2 className="text-white font-bold mb-2 flex items-center gap-2">
              <Trophy size={20} />
              Leaderboard
            </h2>
            {leaderboard.map((entry, i) => (
              <p key={i} className="text-white">
                {entry.name}: {entry.score}
              </p>
            ))}
          </div>
        </div>
      )}

      {/* Game Over Screen */}
      {gameOver && (
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center">
          <div className="bg-white p-8 rounded-xl text-center">
            <h2 className="text-3xl font-bold mb-4">Game Over!</h2>
            <p className="text-xl mb-4">Final Score: {score}</p>
            <div className="mb-6">
              <h3 className="font-bold mb-2">Achievements Unlocked:</h3>
              {Array.from(unlockedAchievements).map((key) => (
                <p key={key} className="text-sm text-yellow-600">
                  {achievements[key as keyof typeof achievements].name}
                </p>
              ))}
            </div>
            <button
              onClick={startGame}
              className="bg-blue-500 text-white font-bold py-2 px-6 rounded-lg hover:bg-blue-600 transition-all"
            >
              Play Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;